package com.poo.prjaula27_08_2025;

import com.poo.prjaula27_08_2025.menus.MenuPrincipal;

public class PrjAula27_08_2025 {

    public static void main(String[] args) {
        MenuPrincipal.menuPrincipal();
        
    }
}
