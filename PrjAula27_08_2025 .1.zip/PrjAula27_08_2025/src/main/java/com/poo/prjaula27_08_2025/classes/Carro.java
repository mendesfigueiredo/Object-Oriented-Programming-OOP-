package com.poo.prjaula27_08_2025.classes;

public class Carro extends Veiculo {
    private String porta;
    private String cavalos;

    public String getPorta() {
        return porta;
    }

    public void setPorta(String porta) {
        this.porta = porta;
    }

    public String getCavalos() {
        return cavalos;
    }

    public void setCavalos(String cavalos) {
        this.cavalos = cavalos;
    }
    
}
