package com.poo.prjaula27_08_2025.classes;

public class Moto extends Veiculo{
    private String partida;
    private String cilindradas;

    public String getPartida() {
        return partida;
    }

    public void setPartida(String partida) {
        this.partida = partida;
    }

    public String getCilindradas() {
        return cilindradas;
    }

    public void setCilindradas(String cilindradas) {
        this.cilindradas = cilindradas;
    }

}
